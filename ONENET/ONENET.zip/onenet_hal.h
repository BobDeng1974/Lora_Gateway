/**
  * @file    onenet_hal.h
  * @author  Liang
  * @version V1.0.0
  * @date    2019-1-6
  * @brief	
  **/
#include "sys.h"
#include "mqtt.h"

#define PROD_ID     "173303"             //�޸�Ϊ�Լ��Ĳ�ƷID
#define SN          "44415968"           //�޸�Ϊ�Լ����豸Ψһ���к�
#define REG_CODE    "wDGNAKmW2T2aEby1"   //�޸�Ϊ�Լ��Ĳ�Ʒע����
#define API_ADDR    "api.heclouds.com"


#define DEVICE_NAME     "text_dev"SN

#define REG_PKT_HEAD    "POST http://"API_ADDR"/register_de?register_code="REG_CODE" HTTP/1.1\r\n"\
                        "Host: "API_ADDR"\r\n"\
                        "Content-Length: "
                    
#define REG_PKT_BODY    "{\"title\":\"123\",\"sn\":\"123\"}"

#define REG_PKT_HEADER  "POST http://api.heclouds.com/register_de?register_code=1233455 HTTP/1.1 \r\n"
//												"Host: api.heclouds.com\r\n"
												
												
struct MqttSampleContext
{
//    int epfd;
//    int mqttfd;
    uint32_t sendedbytes;
    struct MqttContext mqttctx[1];
    struct MqttBuffer mqttbuf[1];

    const char *host;
    unsigned short port;

    const char *proid;
    const char *devid;
    const char *apikey;

    int dup;
    enum MqttQosLevel qos;
    int retain;

    uint16_t pkt_to_ack;
    char cmdid[70];
};

#define STRLEN 64
extern char g_cmdid[STRLEN];

int MQTTClient_Init(void);

void sendPkt(char *p, int len);
void Send_HttpPkt(char* phead,char* pbody);
char *uartDataParse(char *buffer, int32_t *plen);

int MqttSample_Connect(struct MqttSampleContext *ctx, char *proid\
    , char *auth_info, const char *devid, int keep_alive, int clean_session);

//MQTT�������ݰ�
int MqttSample_SendPkt(void *arg, const struct iovec *iov, int iovcnt);
//MQTT�������ݰ�
int MqttSample_RecvPkt(void *arg, void *buf, uint32_t count);

//��ʼ��MQTT
int MqttSample_Init(struct MqttSampleContext *ctx);
//MQTT��Ӧ
int MqttSample_RespCmd(struct MqttSampleContext *ctx, char *resp);
//MQTT�ϴ�����
int MqttSample_Savedata(struct MqttSampleContext *ctx, int temp, int humi);
//MQTT�ϴ�����
int MqttSample_Savedata11(struct MqttSampleContext *ctx, int temp, int humi);
//MQTTȡ������
int MqttSample_Unsubscribe(struct MqttSampleContext *ctx, char **topics, int num);
//MQTT����
int MqttSample_Subscribe(struct MqttSampleContext *ctx, char **topic, int num);
//MQTT������Ϣ
int MqttSample_Publish(struct MqttSampleContext *ctx, int temp, int humi);



/* --Packet Handle-- */

//MQTT CMD Handle
int MqttSample_HandleCmd(void *arg, uint16_t pkt_id, const char *cmdid,
                                int64_t timestamp, const char *desc, const char *cmdarg,
                                uint32_t cmdarg_len, int dup, enum MqttQosLevel qos);

																//MQTT UNSUBACK Handle
int MqttSample_HandleUnsubAck(void *arg, uint16_t pkt_id);
//MQTT SUBACK Handle
int MqttSample_HandleSubAck(void *arg, uint16_t pkt_id, const char *codes, uint32_t count);
//MQTT PUBCOMP Handle
int MqttSample_HandlePubComp(void *arg, uint16_t pkt_id);
//MQTT PUBREL Handle
int MqttSample_HandlePubRel(void *arg, uint16_t pkt_id);
//MQTT PUBREC Handle
int MqttSample_HandlePubRec(void *arg, uint16_t pkt_id);
//MQTT PUBACK Handle	
int MqttSample_HandlePubAck(void *arg, uint16_t pkt_id);
//MQTT PUBLISH Handle	
int MqttSample_HandlePublish(void *arg, uint16_t pkt_id, const char *topic,
                                    const char *payload, uint32_t payloadsize,
                                    int dup, enum MqttQosLevel qos);
//MQTT PINGRSP Handle	
int MqttSample_HandlePingResp(void *arg);
//MQTT CONNACK Handle																		
int MqttSample_HandleConnAck(void *arg, char flags, char ret_code);

																		