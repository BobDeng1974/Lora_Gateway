/**
  * @file    onenet_hal.c
  * @author  Liang
  * @version V1.0.0
  * @date    2019-1-6
  * @brief	
  **/
	
#include "onenet_hal.h"
#include "rtthread.h"
#include "esp8266.h"
#include "usart2.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

char g_cmdid[STRLEN];

/**
 * ����HTTP���ݰ�
 * @param   
 * @return 
 * @brief 
 **/
void Send_HttpPkt(char* phead,char* pbody)
{
	char sendBuf0[20];
	char sendBuf1[500];

	//�ϳ�HTTP���ݰ�
	sprintf(sendBuf1, "%s%d\r\n\r\n%s", phead, (int)rt_strlen(pbody), pbody);
	sprintf(sendBuf0, "AT+CIPSEND=%d\r\n", strlen(sendBuf1));
	//��ջ�������
	USART2_Clear();
	//��ʼ����
	ESP_SendCMD(sendBuf0,">",500);
	/* EDP�豸���Ӱ������� */
	USART2_Write(sendBuf1, rt_strlen(sendBuf1));
}

/**
 * ��͸��ģʽ����EDP����
 * @param   
 * @return 
 * @brief 
 **/
void sendPkt(char *p, int len)
{
    char sendBuf[30] = {0};

    /* ��͸��ģʽ�ȷ���AT+CIPSEND=X */
    sprintf(sendBuf, "AT+CIPSEND=%d\r\n", len);
    ESP_SendCMD(sendBuf, ">", 500);
    USART2_Clear();

    /* EDP�豸���Ӱ������� */
    USART2_Write(p, len);    //���ڷ���
}

/**
  * @brief     �������ݽ���
  * @param     buffer�����ڽ������ݻ���
  * @param     plen�� ���ڱ��������EDP���ݵĳ���
  * @attention ���ڴ������ݲ�����8266ģ����ϱ���Ϣ����Ҫ���������ݽ��н���
  *            ����ģ���ֲᣬ���յ� +IPD, ������յ��˷��������·�����
  * @retval    ����������EDP���ݵ���ָ�룬��û�������򷵻�NULL
  */
char *uartDataParse(char *buffer, int32_t *plen)
{
    char *p;
    char *pnum;
    int32_t len;
	
    if((p = rt_strstr(buffer, "CLOSED")) != NULL)
    {
        rt_kprintf("tcp connection closed\r\n");
    }
    if((p = rt_strstr(buffer, "WIFI DISCONNECT")) != NULL)
    {
        rt_kprintf("wifi disconnected\r\n");
    }
    if((p = rt_strstr(buffer, "WIFI CONNECTED")) != NULL)
    {
        rt_kprintf("wifi connected\r\n");
    }
    if((p = rt_strstr(buffer, "+IPD")) != NULL)
    {
        pnum = p + 5;       //����ͷ���� "+IPD,"��ָ�򳤶��ֶε��׵�ַ
        p = rt_strstr(p, ":"); //ָ�򳤶��ֶ�ĩβ
        *(p++) = '\0';      //�����ֶ�ĩβ���ӽ�������pָ��������·��ĵ�һ���ֽ�
        len = atoi(pnum);
        *plen = len;
        return p;
    }
    return NULL;
}

/**
 * ����MQTT���������
 * @param   
 * @return 
 * @brief 
 **/
int MqttSample_Connect(struct MqttSampleContext *ctx, char *proid\
    , char *auth_info, const char *devid, int keep_alive, int clean_session)
{
	int err;
	
	rt_kprintf("product id: %s\r\nsn: %s\r\ndeviceid: %s\r\nkeepalive: %d\r\ncleansession: %d\r\nQoS: %d\r\n", 
		proid, auth_info, devid, keep_alive, clean_session, MQTT_QOS_LEVEL0);
	
	//���������������ݰ�
	err = Mqtt_PackConnectPkt(ctx->mqttbuf, keep_alive, devid,
															clean_session, NULL,
															NULL, 0,
															MQTT_QOS_LEVEL0, 0, proid,
															auth_info, rt_strlen(auth_info));
	//�ж������Ƿ�ɹ�
	if(MQTTERR_NOERROR != err) {
			rt_kprintf("Failed to pack the MQTT CONNECT PACKET, errcode is %d.\n", err);
			return -1;
	}

   return 0;		
}

/**
 * ���ڽ������ݴ���
 * @param   
 * @return 
 * @brief 
 **/
int MqttSample_RecvPkt(void *arg, void *buf, uint32_t count)
{
	int i;
	int rcv_len = 0, onenetdata_len = 0;
	char buffer[128] = {0};
	char *p = NULL;

	/* ��ɴ������ݰ��Ľ��� */
	while ((rcv_len = USART2_GetRcvNum()) > 0)
	{
			rt_kprintf("rcv_len: %d\r\n", rcv_len);
	}

	if(UASRT2_RX_BUFFER_LEN != 0) //��ͬwifi��ATָ�����Ϣ
	{
			USART2_GetRcvData(buffer, UASRT2_RX_BUFFER_LEN);
			/* �������ݷ���������WIFIģ���������Ϣ����������·���Ϣ */
			if((p = uartDataParse(buffer, &onenetdata_len)) == NULL)
			{
					//printf("No server Data\r\n");
					/* ����Ч���ݣ�����0 */
					return 0;	
			}
			/* �ɹ�������rcv_len���ֽڵ����ݣ�����д��recv_buf�����ڽ��� */
			//WriteBytes(recv_buf, p, rcv_len);
			rt_memcpy(buf, p, onenetdata_len);

			if(onenetdata_len > 0)
			{
					rt_kprintf("Rcv: \r\n");
					for(i=0; i<onenetdata_len; i++)
					{
							rt_kprintf("%02X ", ((unsigned char *)buf)[i]);
					}
					rt_kprintf("\r\n");
			}
	}
	return onenetdata_len;
}

int MqttSample_SendPkt(void *arg, const struct iovec *iov, int iovcnt)
{
	char sendbuf[1024];
	int len = 0;
	int bytes;
	int i=0,j=0;
	
	rt_kprintf("send one pkt\n");
	for(i=0; i<iovcnt; ++i)
	{
		char *pkg = (char*)iov[i].iov_base;
		for(j=0; j<iov[i].iov_len; ++j)
		{
			printf("%02X ", pkg[j]&0xFF);
		}
		rt_kprintf("\n");
		rt_memcpy(sendbuf+len, iov[i].iov_base, iov[i].iov_len);
		len += iov[i].iov_len;
	}
	sendPkt(sendbuf, len);
	rt_kprintf("send over\n");

	return bytes;
}

//------------------------------- packet handlers -------------------------------------------
/**
 * ����ȷ�ϰ�
 * @param   
 * @return 
 * @brief 
 **/
int MqttSample_HandleConnAck(void *arg, char flags, char ret_code)
{
	rt_kprintf("Success to connect to the server, flags(%0x), code(%d).\n",
				 flags, ret_code);
	return 0;
}

/**
 * ping��Ӧ��
 * @param   
 * @return 
 * @brief 
 **/
int MqttSample_HandlePingResp(void *arg)
{
    rt_kprintf("Recv the ping response.\n");
    return 0;
}

/**
 * ����
 * @param   
 * @return 
 * @brief 
 **/
int MqttSample_HandlePublish(void *arg, uint16_t pkt_id, const char *topic,
                                    const char *payload, uint32_t payloadsize,
                                    int dup, enum MqttQosLevel qos)
{
    struct MqttSampleContext *ctx = (struct MqttSampleContext*)arg;
    ctx->pkt_to_ack = pkt_id;
    ctx->dup = dup;
    ctx->qos = qos;
    rt_kprintf("dup: %d, qos: %d, id: %d\r\ntopic: %s\r\npayloadsize: %d  payload: %s\r\n",
           dup, qos, pkt_id, topic, payloadsize, payload);

	

    /*fix me : add response ?*/

    //get cmdid
    //$creq/topic_name/cmdid
    rt_memset(g_cmdid, STRLEN, 0);
    if('$' == topic[0] &&
        'c' == topic[1] &&
        'r' == topic[2] &&
        'e' == topic[3] &&
        'q' == topic[4] &&
        '/' == topic[5]){
        int i=6;
        while(topic[i]!='/' && i<rt_strlen(topic)){
            ++i;
        }
        if(i<rt_strlen(topic))
            rt_memcpy(g_cmdid, topic+i+1, rt_strlen(topic+i+1));
    }
    return 0;
}

int MqttSample_HandlePubAck(void *arg, uint16_t pkt_id)
{
    rt_kprintf("Recv the publish ack, packet id is %d.\n", pkt_id);
    return 0;
}

int MqttSample_HandlePubRec(void *arg, uint16_t pkt_id)
{
    struct MqttSampleContext *ctx = (struct MqttSampleContext*)arg;
    ctx->pkt_to_ack = pkt_id;
    rt_kprintf("Recv the publish rec, packet id is %d.\n", pkt_id);
    return 0;
}

int MqttSample_HandlePubRel(void *arg, uint16_t pkt_id)
{
    struct MqttSampleContext *ctx = (struct MqttSampleContext*)arg;
    ctx->pkt_to_ack = pkt_id;
    rt_kprintf("Recv the publish rel, packet id is %d.\n", pkt_id);
    return 0;
}

int MqttSample_HandlePubComp(void *arg, uint16_t pkt_id)
{
    rt_kprintf("Recv the publish comp, packet id is %d.\n", pkt_id);
    return 0;
}

int MqttSample_HandleSubAck(void *arg, uint16_t pkt_id, const char *codes, uint32_t count)
{
    uint32_t i;
    rt_kprintf("Recv the subscribe ack, packet id is %d, return code count is %d:.\n", pkt_id, count);
    for(i = 0; i < count; ++i) {
        unsigned int code = ((unsigned char*)codes)[i];
        printf("   code%d=%02x\n", i, code);
    }

    return 0;
}


int MqttSample_HandleUnsubAck(void *arg, uint16_t pkt_id)
{
    rt_kprintf("Recv the unsubscribe ack, packet id is %d.\n", pkt_id);
    return 0;
}

int MqttSample_HandleCmd(void *arg, uint16_t pkt_id, const char *cmdid,
                                int64_t timestamp, const char *desc, const char *cmdarg,
                                uint32_t cmdarg_len, int dup, enum MqttQosLevel qos)
{
    uint32_t i;
    char cmd_str[100] = {0};
    struct MqttSampleContext *ctx = (struct MqttSampleContext*)arg;
    
		ctx->pkt_to_ack = pkt_id;
    strcpy(ctx->cmdid, cmdid);
    rt_kprintf("Recv the command, packet id is %d, cmduuid is %s, qos=%d, dup=%d.\n",
           pkt_id, cmdid, qos, dup);

    if(0 != timestamp) {
        time_t seconds = timestamp / 1000;
        struct tm *st = localtime(&seconds);

        rt_kprintf("    The timestampe is %04d-%02d-%02dT%02d:%02d:%02d.%03d.\n",
               st->tm_year + 1900, st->tm_mon + 1, st->tm_mday,
               st->tm_hour, st->tm_min, st->tm_sec, (int)(timestamp % 1000));
    }
    else {
        rt_kprintf("    There is no timestamp.\n");
    }

    if(NULL != desc) {
        rt_kprintf("    The description is: %s.\n", desc);
    }
    else {
        rt_kprintf("    There is no description.\n");
    }

    rt_kprintf("    The length of the command argument is %d, the argument is:", cmdarg_len);

    for(i = 0; i < cmdarg_len; ++i) {
        const char c = cmdarg[i];
        if(0 == i % 16) {
            rt_kprintf("\n        ");
        }
        rt_kprintf("%02X'%c' ", c, c);
    }
    rt_kprintf("\n");
    rt_memcpy(cmd_str, cmdarg, cmdarg_len);
    rt_kprintf("cmd: %s\r\n", cmd_str);

    return 0;
}

int MqttSample_Subscribe(struct MqttSampleContext *ctx, char **topic, int num)
{
    int err;

    err = Mqtt_PackSubscribePkt(ctx->mqttbuf, 2, MQTT_QOS_LEVEL0, topic, num);
    if(err != MQTTERR_NOERROR) {
        rt_kprintf("Critical bug: failed to pack the subscribe packet.\n");
        return -1;
    }

    return 0;
}

int MqttSample_Unsubscribe(struct MqttSampleContext *ctx, char **topics, int num)
{
    int err;

    err = Mqtt_PackUnsubscribePkt(ctx->mqttbuf, 3, topics, num);
    if(err != MQTTERR_NOERROR) {
        rt_kprintf("Critical bug: failed to pack the unsubscribe packet.\n");
        return -1;
    }

    return 0;
}

int MqttSample_Savedata11(struct MqttSampleContext *ctx, int temp, int humi)
{
	int err;
	uint16_t pkt_id = 1; 

	char json[]="{\"datastreams\":[{\"id\":\"temp\",\"datapoints\":[{\"value\":%d}]},{\"id\":\"humi\",\"datapoints\":[{\"value\":%d}]}]}";
	char t_json[200];
	int payload_len;
	char *t_payload;
	unsigned short json_len;
    
	sprintf(t_json, json, temp, humi);
	payload_len = 1 + 2 + rt_strlen(t_json)/sizeof(char);
	json_len = rt_strlen(t_json)/sizeof(char);
	
	t_payload = (char *)rt_malloc(payload_len);
	if(t_payload == NULL)
	{
			rt_kprintf("<%s>: t_payload malloc error\r\n", __FUNCTION__);
			return 0;
	}

	//type
	t_payload[0] = '\x01';

	//length
	t_payload[1] = (json_len & 0xFF00) >> 8;
	t_payload[2] = json_len & 0xFF;

	//json
	rt_memcpy(t_payload+3, t_json, json_len);

	if(ctx->mqttbuf->first_ext) {
			return MQTTERR_INVALID_PARAMETER;
	}
	
	rt_kprintf("Topic: %s\r\nPakect ID: %d\r\nQoS: %d\r\nPayload: %s\r\n", 
		"$dp", pkt_id, MQTT_QOS_LEVEL1, t_json);
	err = Mqtt_PackPublishPkt(ctx->mqttbuf, pkt_id, "$dp", t_payload, payload_len, \
	MQTT_QOS_LEVEL1, 0, 1);
    
   rt_free(t_payload);

	if(err != MQTTERR_NOERROR) {
			return err;
	}

  return 0;
}

int MqttSample_Savedata(struct MqttSampleContext *ctx, int temp, int humi)
{
    int Qos=1;
    int type = 1;
    /*-q 0/1   ----> Qos0/Qos1
      -t 1/7   ----> json/float datapoint
    */


    printf("Qos: %d    Type: %d\r\n", Qos, type);
    MqttSample_Savedata11(ctx, temp, humi); // qos=1 type=1
}



int MqttSample_Publish(struct MqttSampleContext *ctx, int temp, int humi)
{
	int err;
	int topics_len = 0;
	struct MqttExtent *ext;
	
	char *topic = "key_press";
	char *payload1= "key pressed, temp: %d, humi: %d";
	char payload[100] = {0};
	int pkg_id = 1;

	sprintf(payload, payload1, temp, humi);
	rt_kprintf("<%s>: public %s : %s\r\n", __FUNCTION__, topic, payload);

	if(ctx->mqttbuf->first_ext) {
			return MQTTERR_INVALID_PARAMETER;
	}

	/*
	std::string pkg_id_s(topics+3);
	int pkg_id = std::stoi(pkg_id_s);
	*/
    
	err = Mqtt_PackPublishPkt(ctx->mqttbuf, pkg_id, topic, payload, strlen(payload), MQTT_QOS_LEVEL1, 0, 1);

	if(err != MQTTERR_NOERROR) {
			return err;
	}

	return 0;
}

/* �ظ����� */
int MqttSample_RespCmd(struct MqttSampleContext *ctx, char *resp)
{
	int err;
	int Qos=0;

	rt_kprintf("QoS: %d\r\nCmdId: %s\r\n", Qos, ctx->cmdid);

	if(0==Qos)
	{
			err = Mqtt_PackCmdRetPkt(ctx->mqttbuf, 1, ctx->cmdid,
															 resp, 11, MQTT_QOS_LEVEL0, 1);
	}
	else if(1==Qos)
	{
			err = Mqtt_PackCmdRetPkt(ctx->mqttbuf, 1, ctx->cmdid,
															 resp, 11, MQTT_QOS_LEVEL1, 1);
	}

	if(MQTTERR_NOERROR != err) {
			printf("Critical bug: failed to pack the cmd ret packet.\n");
			return -1;
	}

	return 0;
}

/**
 * ��ʼ��MQTT�ͻ���
 * @param   MqttSampleContext[MQTTʵ��������ָ��]
 * @return 	0[OK] -1[ERROR]
 * @brief 
 **/
int MqttSample_Init(struct MqttSampleContext *ctx)
{
	//struct epoll_event event;
	int err;

	ctx->host = MQTT_HOST;
	ctx->port = MQTT_PORT;
	ctx->sendedbytes = -1;
	
	ctx->devid = NULL;
	ctx->cmdid[0] = '\0';

	//��ʼ��MQTT�ײ�����ʱ������
	err = Mqtt_InitContext(ctx->mqttctx, 1000);
	//��ʼ��ʧ�ܷ���
  if(MQTTERR_NOERROR != err) {
			rt_kprintf("Failed to init MQTT context errcode is %d", err);
			return -1;
	}
	//װ��MQTT��д����
	ctx->mqttctx->read_func = MqttSample_RecvPkt;
	ctx->mqttctx->writev_func = MqttSample_SendPkt;
	//װ��MQTT�������
	ctx->mqttctx->handle_conn_ack = MqttSample_HandleConnAck;
	ctx->mqttctx->handle_conn_ack_arg = ctx;
	ctx->mqttctx->handle_ping_resp = MqttSample_HandlePingResp;
	ctx->mqttctx->handle_ping_resp_arg = ctx;
	ctx->mqttctx->handle_publish = MqttSample_HandlePublish;
	ctx->mqttctx->handle_publish_arg = ctx;
	ctx->mqttctx->handle_pub_ack = MqttSample_HandlePubAck;
	ctx->mqttctx->handle_pub_ack_arg = ctx;
	ctx->mqttctx->handle_pub_rec = MqttSample_HandlePubRec;
	ctx->mqttctx->handle_pub_rec_arg = ctx;
	ctx->mqttctx->handle_pub_rel = MqttSample_HandlePubRel;
	ctx->mqttctx->handle_pub_rel_arg = ctx;
	ctx->mqttctx->handle_pub_comp = MqttSample_HandlePubComp;
	ctx->mqttctx->handle_pub_comp_arg = ctx;
	ctx->mqttctx->handle_sub_ack = MqttSample_HandleSubAck;
	ctx->mqttctx->handle_sub_ack_arg = ctx;
	ctx->mqttctx->handle_unsub_ack = MqttSample_HandleUnsubAck;
	ctx->mqttctx->handle_unsub_ack_arg = ctx;
	ctx->mqttctx->handle_cmd = MqttSample_HandleCmd;
	ctx->mqttctx->handle_cmd_arg = ctx;
	//��ʼ��MQTT������
	MqttBuffer_Init(ctx->mqttbuf);

	return 0;
}

int MQTTClient_Init(void)
{
	
}

